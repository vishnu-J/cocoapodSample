//
//  ios.h
//  ios
//
//  Created by Mathan on 20/07/18.
//  Copyright © 2018 GreedyGame. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ios.
FOUNDATION_EXPORT double iosVersionNumber;

//! Project version string for ios.
FOUNDATION_EXPORT const unsigned char iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ios/PublicHeader.h>


